@extends('layouts.user')
@push('css')
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        .borde{
            border-radius: 0.55rem!important;
        }
    </style>
@endpush
@section('content')
 
<script src="https://www.paypal.com/sdk/js?client-id=AVZGP8lxfDPrBPU_7JIIl6HO2uw3zFSSm1Nr7Y_x55PIFcqGSWALbpRjv_XR-GbANoDc2bMYk8-wYLQp&disable-funding=credit,card"></script>

<div class="xt-page-title-area">
        <div class="xt-page-title">
            <div class="continer">
                <h1 class="entry-title">DashBoard</h1>
            </div>
        </div>
        <div class="xt-breadcrumb-wrapper">
            <div class="continer">
                <nav class="xt-breadcrumb">
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li class="current">DashBoard</li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>



    <div class="continer">
        <div class="theme-main-content-inner row justify-content-center">
           
            <div class="row profile_page_container">
                @include('user.include.dheader')
                <div class="col-md-6 left_section_container">
                    <h3 style="text-align: left;"><i class="fa fa-envelope-open-o" aria-hidden="true"></i>My Profile</h3>
                    <div class="row">
                       <br>
                        <div class="col-md-4 section_container">
                            <div class="row">
                                <div class="col-lg-12 profile_img_section">
                                    
                                    <img src="user/images/avatar_new.png">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>                
                <div class="col-md-6 right_section_container">
                    <br><br>
                    @php
                        $user = Auth::user();
                    @endphp
                        <div class="form-group row">
                            <span   class="col-sm-4 displa-4 col-form-label">Full Name:</span>
                            <div class="col-sm-8">
                              <input type="text" name="name" class="form-control-plaintext borde text-muted" placeholder="Enter Your Name" value="{{  $user->name }}">
                            </div>
                        </div>

                        <div class="form-group row">
                            <span   class="col-sm-4 displa-4 col-form-label">MemberSince:</span>
                            <div class="col-sm-8">
                              <input type="date" class="form-control-plaintext borde text-muted">
                            </div>
                        </div>

                        <div class="form-group row">
                            <span   class="col-sm-4 displa-4 col-form-label">Member Id:</span>
                            <div class="col-sm-8">
                              <input type="text" readonly class="form-control-plaintext borde text-muted" placeholder="123456789" value="{{ $user->id }}">
                            </div>
                        </div>

                        <div class="form-group row">
                            <span   class="col-sm-4 displa-4 col-form-label">Year Left:</span>
                            <div class="col-sm-8">
                              <input type="date" class="form-control-plaintext borde text-muted">
                            </div>
                        </div>

                        <div class="form-group row">
                            <span   class="col-sm-4 displa-4 col-form-label">Company:</span>
                            <div class="col-sm-8">
                              <input type="text" class="form-control-plaintext borde text-muted" placeholder="Jonathan & Smith">
                            </div>
                        </div>

                        <div class="form-group row">
                            <span   class="col-sm-4 displa-4 col-form-label">Title:</span>
                            <div class="col-sm-8">
                              <input type="text" class="form-control-plaintext borde text-muted" placeholder="VicePresident">
                            </div>
                        </div>

                        <div class="form-group row">
                            <span   class="col-sm-4 displa-4 col-form-label">Email:</span>
                            <div class="col-sm-8">
                              <input type="email" name="email" value="{{ $user->email }}" class="form-control-plaintext borde text-muted" placeholder="enter Your Email">
                            </div>
                        </div>

                        <div class="form-group row">
                            <span   class="col-sm-4 displa-4 col-form-label">Phone:</span>
                            <div class="col-sm-8">
                              <input type="text" class="form-control-plaintext borde text-muted" placeholder="Phone No.">
                            </div>
                        </div>

   

                        <div class="form-group float-right">
                            <div id="advertiserpay"></div>
                            <input class="center btn btn-lg btn-fill " type="submit" placeholder="Submit"  id="advertiserformbtn">
                        </div>


                </div>                
            </div>
           
        </div>
    </div>
            
           
        
      
  
 

@endsection
@push('js')

@endpush
