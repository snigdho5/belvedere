@extends('layouts.user')
@push('css')
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .borde {
            border-radius: 0.55rem !important;
        }

    </style>
@endpush
@section('content')


    <div class="xt-page-title-area">
        <div class="xt-page-title">
            <div class="continer">
                <h1 class="entry-title">DashBoard</h1>
            </div>
        </div>
        <div class="xt-breadcrumb-wrapper">
            <div class="continer">
                <nav class="xt-breadcrumb">
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li class="current">DashBoard</li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>



    <div class="continer">
        <div class="theme-main-content-inner row justify-content-center">

            <div class="row profile_page_container">
                @include('user.include.dheader')
                <div class="col-md-12">



                    {{-- <i class="fal fa-bullhorn"></i> --}}

                    <div class="row">
                        <div class="col-md-6">
                            <h3 style="text-align: left;"><i class="fa fa-bullhorn" aria-hidden="true"></i>My ADVERTISEMENT
                            </h3>
                        </div>
                        <div class="col-md-6">
                            <div class="float-right">
                                <button><i class="fa fa-plus"></i>Add</button>
                            </div>
                        </div>

                        <div class="col-md-8 section_container center">

                            <ul class="row reptro-course-items event">
                                <li class="course  col-lg-12 col-md-12">
                                    <div class="reptro-course-loop-thumbnail-area">
                                        <!-- <div class="reptro-course-details-btn"> <a class="btn btn-fill btn-lg" href="events-details.html">Apply</a></div> -->
                                        <div class="course-thumbnail"> <img width="570" height="461"
                                                src="user/images/rawpixel.jpg"></div>
                                    </div>
                                    <div class="reptro-course-item-inner"> <a href="#" class="course-permalink">
                                            <h3 class="course-title">Intel Computing<span class="just_lable">Location:
                                                    Dublin | Category: information Technology</span><span
                                                    class="full_time_lable">Full time</span></h3>
                                        </a>
                                        <div class="event-info">
                                            <div class="reptro-event-date"><span class="reptro-event-month">POsted on</span>
                                                <span class="reptro-event-day">31</span> <span
                                                    class="reptro-event-month">Dec</span> <span
                                                    class="reptro-event-year">2020</span></div>
                                            <div class="venueTime">
                                                <span class="reptro-event-time">
                                                    <h6>Job Description</h6>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                                        industry. Lorem Ipsum has been the industry’s standard dummy text .

                                                        When an unknown printer took a galley of type and scrambled it to
                                                        make a type specimen book.</p>
                                                    <!-- <i class="sli-clock"></i>Thursday, 3:00 pm to 6:00 pm -->
                                                </span>
                                                <span class="reptro-event-venue"><i class="sli-location-pin"></i>PSC
                                                    Convention Hall</span>
                                                <a class="btn btn-fill btn-lg" href="events-details.html">Apply</a>
                                            </div>
                                        </div>
                                    </div>

                                </li>

                            </ul>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>







@endsection
@push('js')
<script src="js/choices.js"></script>
    <script>
      const customSelects = document.querySelectorAll("select");
      const deleteBtn = document.getElementById('delete')
      const choices = new Choices('select',
      {
        searchEnabled: false,
        itemSelectText: '',
        removeItemButton: true,
      });
      for (let i = 0; i < customSelects.length; i++)
      {
        customSelects[i].addEventListener('addItem', function(event)
        {
          if (event.detail.value)
          {
            let parent = this.parentNode.parentNode
            parent.classList.add('valid')
            parent.classList.remove('invalid')
          }
          else
          {
            let parent = this.parentNode.parentNode
            parent.classList.add('invalid')
            parent.classList.remove('valid')
          }
        }, false);
      }
      deleteBtn.addEventListener("click", function(e)
      {
        e.preventDefault()
        const deleteAll = document.querySelectorAll('.choices__button')
        for (let i = 0; i < deleteAll.length; i++)
        {
          deleteAll[i].click();
        }
      });

    </script>
@endpush
